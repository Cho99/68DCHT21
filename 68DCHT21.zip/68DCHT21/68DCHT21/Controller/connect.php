<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$database = "test";

$connect = mysqli_connect($hostname, $username, $password, $database);
 ?>