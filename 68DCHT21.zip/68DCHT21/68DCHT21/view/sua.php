<?php require '../Model/server.php'; ?>
<?php 
if (isset($_GET['sua'])) {
	$id = $_GET['sua'];
	
	$query = "SELECT * FROM student WHERE id = '$id'";
	$data_sua = mysqli_query($connect, $query);
	$row = mysqli_fetch_assoc($data_sua);
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Thêm Mới Sinh Viên</title>
	<script type="text/javascript" src="../public/vendor/bootstrap.js"></script>
	<script type="text/javascript" src="../public/scripts/1.js"></script>
	<link rel="stylesheet" href="../public/vendor/bootstrap.css">
	<!-- <link rel="stylesheet" href="styles/main.css"> -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
</head>
<body>
	<div class="alert-success" align="center">
		<h1>Thêm mới sinh viên</h1> 
	</div>
	<form action="../Model/server.php" method="post">
		<input type="hidden" name="id" value="<?= $row['id'] ?>">
		<div class="form-group">
			<label for="hoten"><h5>Họ và tên:</h5></label>
			<input type="text" class="form-control" name="hoten" value="<?= $row['hoten'] ?>">
		</div>
		<div class="form-group">
			<label for="namsinh"><h5>Ngày sinh:</h5></label>
			<input type="date" class="form-control" name="namsinh" value="<?= $row['namsinh'] ?>">
		</div>
		<div class="form-group">
			<label for="diem"><h5 style="color: red">Điểm:</h5></label>
			<input type="text" class="form-control" name="diem" value="<?= $row['diem'] ?>">
		</div>
		
		<button type="submit" class="btn btn-outline-light" name="sua">Sửa</button>
	</form>
	<footer class="page-footer font-small blue pt-4">

  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <h5 class="text-uppercase">Footer</h5>
        <p>copyright © by Dog 2019.</p>

      </div>
  </div>
  <!-- Footer Links -->
</footer>
<!-- Footer -->
</body>
</html>