<?php require '../Model/server.php'; ?>
<?php if (isset($_POST['timkiem'])) {
	$key = $_POST['key'];
	$key = addslashes($key);
	$data = mysqli_query($connect, "SELECT * FROM student WHERE LOWER(hoten) LIKE '%$key%' OR namsinh LIKE '%$key%' OR diem LIKE '%$key%'");
} ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sinh Viên</title>
	<script type="text/javascript" src="../public/vendor/bootstrap.js"></script>
	<script type="text/javascript" src="../public/scripts/1.js"></script>
	<link rel="stylesheet" href="../public/vendor/bootstrap.css">
	<!-- <link rel="stylesheet" href="styles/main.css"> -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
</head>
<body>
	<div class="alert-info" align="center">
		<h1>68DCHT21</h1> 
	</div>
	<div class="container first">
		<div class="row" style="display: flex; justify-content: center;">
			<div class="alert-primary">
				<h3>Thông Tin Sinh Viên</h3>
			</div>
		</div>
		<div class="row" style="display: flex; justify-content: center;" >
				<form action="" class="form-inline" method="post">
					<div class="form-group">
						<input style="width: 100%" type="text" name="key" class="form-control small">
					</div>
					<button type="submit" class="btn btn-outline-primary" name="timkiem">Tìm Kiếm</button>
				</form>
		</div>
		<br>
		<div class="row" style="display: flex; justify-content: center;">
			<div class="col-sm-9">
				<form>
					<table class="table table-hover table-striped table-bordered" style="text-align: center; border:1px solid">
						<thead>
							<tr>
								<th scope="row">#ID</th>
								<th class="table-info">Họ và Tên</th>
								<th>Năm Sinh</th>
								<th class="table-success">Điểm</th>
								<th>Thao Tác</th>
								<td><a href="them.php" type="submit" class="btn btn-success btn-sm">Thêm mới</a></td>
							</tr>
						</thead>
						<tbody>
							<?php while ($row = mysqli_fetch_assoc($data)) { ?>
								<tr>
									<th scope="row"><?= $row['id'] ?></th>
									<td class="table-info"><?= $row['hoten'] ?></td>
									<td><?= $row['namsinh'] ?></td>
									<th class="table-success"><?= $row['diem'] ?></th>
									<td><a href="../Model/server.php?xoa=<?= $row['id'] ?>" name="xoa" class="btn btn-success btn-sm btn-outline-danger">Xóa</a></td>
									<td><a href="sua.php?sua=<?= $row['id'] ?>" name="sua" class="btn btn-success btn-sm btn-outline-danger">Sửa</a></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</form>
				
			</div>
		</div>
	</div>
	<!-- Footer -->
	<footer class="page-footer font-small blue pt-4">

		<!-- Footer Links -->
		<div class="container-fluid text-center text-md-left">

			<!-- Grid row -->
			<div class="row">

				<!-- Grid column -->
				<div class="col-md-6 mt-md-0 mt-3">

					<!-- Content -->
					<h5 class="text-uppercase">Footer</h5>
					<p>copyright © by Dog 2019.</p>

				</div>
			</div>
			<!-- Footer Links -->
		</footer>
		<!-- Footer -->
	</body>
	</html>

